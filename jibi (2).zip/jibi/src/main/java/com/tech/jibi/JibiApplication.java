package com.tech.jibi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JibiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JibiApplication.class, args);
	}

}
