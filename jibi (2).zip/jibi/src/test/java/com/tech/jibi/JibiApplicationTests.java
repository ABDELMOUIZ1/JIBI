package com.tech.jibi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JibiApplicationTests {

	@Test
	void contextLoads() {
	}

}
